from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from recipes import views


urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/recipes/', views.RecipeListView.as_view()), # creates a URL that allows you to view and create recipes you then need to create a superuser
    path('api/recipes/create', views.RecipeCreateView.as_view()),
    path('api/recipes/<int:pk>', views.RecipeDetailView.as_view()), # creates the URL that lets you see the recipes details 
    path('api/recipes/<int:pk>/update/', views.RecipeUpdateView.as_view()), #creates the URL that allows you to update recipes
    path('api/recipes/<int:pk>/upvote/', views.CreateUpvoteView.as_view()), # the int part makes that part an integer
    path('api/ingredients/', views.IngredientCreateView.as_view()), # creates a URL for Ingredients
    path('api/register/', views.UserRegistrationView.as_view()), # creates a registration page

] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT) # this creates a URL for the media files
